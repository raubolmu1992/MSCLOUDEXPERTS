USE [Halterofilia]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



ALTER procedure [dbo].[usp_registrar](
@PaisNombre varchar(60),
@Nombre varchar(60),
@PaisID varchar(60),
@UsuarioID varchar(60),
@Tipo varchar(60),
@Arranque int,
@Envion varchar(60),
@TotalPeso varchar(60),
@RegistroID int

)
as
begin


Declare @ValPaisID INT
Declare @ValUsuarioID INT
Declare @ValRegistroID INT


--Insertar Paises 
insert into Paises(PaisNombre)
values
(
@PaisNombre
)


SET @ValPaisID = (SELECT TOP 1 PaisID FROM Paises ORDER BY PaisID DESC)


--Insertar Usuarios 
insert into Usuarios(Nombre,PaisID,Contrasena)
values
(
@Nombre,
@ValPaisID,
123
)

SET @ValUsuarioID = (SELECT TOP 1 UsuarioID FROM Usuarios ORDER BY UsuarioID DESC)

--Insertar Registros 
insert into Registros(UsuarioID,Tipo,Arranque,Envion,TotalPeso)
values
(
@ValUsuarioID,
@Tipo,
@Arranque,
@Envion,
@TotalPeso
)


SET @ValRegistroID = (SELECT TOP 1 RegistroID FROM Registros ORDER BY RegistroID DESC)

--Insertar Intentos 
insert into Intentos(RegistroID,NumIntentos)
values
(
@ValRegistroID,
1
)




end

go
alter procedure usp_listar
as
begin

	select p.PaisNombre, u.Nombre, r.Tipo, r.Arranque, r.Envion, r.TotalPeso, i.NumIntentos,p.PaisID,r.UsuarioID,r.RegistroID  from Paises p, Usuarios u, Registros r, Intentos i
	where p.PaisID = u.PaisID and r.UsuarioID = u.UsuarioID and r.RegistroID = i.RegistroID
	order by r.TotalPeso desc
	FOR JSON PATH
end


go

alter procedure usp_obtener
 @PaisID int
as
begin

	select p.PaisNombre, u.Nombre, r.Tipo, r.Arranque, r.Envion, r.TotalPeso, i.NumIntentos,p.PaisID,r.UsuarioID,r.RegistroID  from Paises p, Usuarios u, Registros r, Intentos i
	where p.PaisID = u.PaisID and r.UsuarioID = u.UsuarioID and r.RegistroID = i.RegistroID
	and p.paisID = @PaisID
	order by r.TotalPeso desc
	FOR JSON PATH
end

go
alter procedure usp_modificar
@PaisNombre varchar(60),
@Nombre varchar(60),
@PaisID varchar(60),
@UsuarioID varchar(60),
@Tipo varchar(60),
@Arranque int,
@Envion varchar(60),
@TotalPeso varchar(60),
@RegistroID int,
@NumIntentos int
as
begin

update Paises
set  PaisNombre = @PaisNombre
where PaisID = @PaisID

update Usuarios
set  Nombre = @Nombre
where PaisID = @PaisID and UsuarioID = @UsuarioID

update Registros
set  Arranque = @Arranque,
     Envion = @Envion,
     TotalPeso = @TotalPeso
where UsuarioID = @UsuarioID

update Intentos
set  NumIntentos = @NumIntentos
where RegistroID = @RegistroID 


end


GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--Listar Usuarios
alter procedure [dbo].[usp_ListarUsuarios](
@Usuario varchar(60),
@Contrasena varchar(60)
)
as
begin

Select * from Usuarios where Nombre = @Usuario and Contrasena = @Contrasena

end
