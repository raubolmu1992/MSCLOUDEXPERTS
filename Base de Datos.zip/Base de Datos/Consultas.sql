

  select * from  [Halterofilia].[dbo].[Usuarios]
  select * from  [Halterofilia].[dbo].[Paises]
  select * from  [Halterofilia].[dbo].[Registros]
  select * from  [Halterofilia].[dbo].[Intentos]

    USE [Halterofilia]
  delete  from  [Halterofilia].[dbo].[Registros]
  delete  from  [Halterofilia].[dbo].[Intentos]
  delete  from  [Halterofilia].[dbo].[Usuarios]
  delete  from  [Halterofilia].[dbo].[Paises]

  USE [Halterofilia]

  DROP TABLE [Halterofilia].[dbo].[Registros]
  DROP TABLE [Halterofilia].[dbo].[Intentos]
  DROP TABLE [Halterofilia].[dbo].[Usuarios]
  DROP TABLE [Halterofilia].[dbo].[Paises]