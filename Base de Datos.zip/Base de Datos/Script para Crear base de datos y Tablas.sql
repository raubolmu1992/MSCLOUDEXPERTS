use master
go
IF NOT EXISTS(SELECT name FROM master.dbo.sysdatabases WHERE NAME = 'Halterofilia')
CREATE DATABASE Halterofilia

GO 
USE Halterofilia
GO


CREATE TABLE Paises (
    PaisID INT PRIMARY KEY IDENTITY(1,1),
    PaisNombre VARCHAR(100) NOT NULL
);

CREATE TABLE Usuarios (
    UsuarioID INT PRIMARY KEY IDENTITY(1,1),
    Nombre VARCHAR(50) NOT NULL,
	Contrasena VARCHAR(50) NOT NULL,
    PaisID INT,
    FOREIGN KEY (PaisID) REFERENCES Paises(PaisID)
);

CREATE TABLE Registros (
    RegistroID INT PRIMARY KEY IDENTITY(1,1),
    UsuarioID INT,
    FOREIGN KEY (UsuarioID) REFERENCES Usuarios(UsuarioID),
    Tipo VARCHAR(50) NOT NULL,
    Arranque INT NOT NULL,
    Envion INT NOT NULL,
    TotalPeso INT  NOT NULL
);

CREATE TABLE Intentos (
    IntentosID INT PRIMARY KEY IDENTITY(1,1),
    RegistroID INT,
	NumIntentos INT,
    FOREIGN KEY (RegistroID) REFERENCES Registros(RegistroID),
);
